import React from 'react'
import { Link } from 'react-router-dom'
import './Login.css';

export default function Login() {
  return (
    <div className="container-fluid login-container">
  <div className="row w-100 justify-content-center">
    <div className="col-md-6 d-flex align-items-center justify-content-center">
      <div className="login-form">
        <h2>Login</h2>
        <form>
          <div className="mb-3">
            <input type="email" className="form-control" placeholder="Email" />
          </div>
          <div className="mb-3">
            <input type="password" className="form-control" placeholder="Password" />
          </div>
          <button type="submit" className="btn btn-primary w-100">Login</button>
        </form>
        <p>Don't have an account? <Link to="/signup">Sign up</Link></p>
      </div>
    </div>
  </div>
</div>
  )
}
