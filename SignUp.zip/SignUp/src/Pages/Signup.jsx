import React from 'react'
import { Link } from 'react-router-dom'
import './Signup.css';


export default function Signup() {
  return (
    <div className="container-fluid signup-container">
  <div className="signup-form">
    <div className="container-fluid vh-100 d-flex align-items-center justify-content-center bg-light">
      <div className="row w-100">
        <div className="col-md-6 d-none d-md-block p-0">
        </div>
        <div className="col-md-6 d-flex align-items-center justify-content-center">
          <div className="w-75">
            <h2 className="text-center mb-4 text-primary">Create Account</h2>
            <form>
              <div className="mb-3">
                <input type="text" className="form-control" placeholder="Full Name" />
              </div>
              <div className="mb-3">
                <input type="email" className="form-control" placeholder="Email" />
              </div>
              <div className="mb-3">
                <input type="password" className="form-control" placeholder="Password" />
              </div>
              <button type="submit" className="btn btn-primary w-100">Sign Up</button>
            </form>
            <p className="text-center mt-3">
              Already have an account? <Link to="/login">Login</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
  )
}

