package com.Flight_Management.BookingMicroservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Flight_Management.BookingMicroservice.Exceptions.InvalidBookingException;
import com.Flight_Management.BookingMicroservice.Exceptions.InvalidPassengerException;
import com.Flight_Management.BookingMicroservice.Services.BookingService;
import com.Flight_Management.BookingMicroservice.Utility.BookingDto;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/booking")
public class BookingController {
	@Autowired
	private BookingService bookingService;
	
	@PostMapping("/add")
    public ResponseEntity<BookingDto> addBooking(@Valid @RequestBody BookingDto bookingDTO) throws InvalidPassengerException, InvalidBookingException {
        return new ResponseEntity<>(bookingService.addBooking(bookingDTO), HttpStatus.CREATED);
    }

    @GetMapping("")
    public ResponseEntity<List<BookingDto>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookingDto> getBookingById(@PathVariable Long id) throws InvalidBookingException {
        return ResponseEntity.ok(bookingService.getBookingById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<BookingDto> updateBooking(@PathVariable Long id,
                                                    @Valid @RequestBody BookingDto bookingDTO) throws InvalidBookingException {
        return ResponseEntity.ok(bookingService.updateBooking(id, bookingDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBooking(@PathVariable Long id) throws InvalidBookingException {
        bookingService.deleteBooking(id);
        return ResponseEntity.ok("Booking with ID " + id + " deleted successfully.");
    }
	
}
