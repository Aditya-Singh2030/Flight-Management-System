package com.Flight_Management.BookingMicroservice.Entity;



import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
public class Booking {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;

	@NotNull(message = "Flight ID is required")
    private Long flightId;

	@NotNull(message = "User ID is required")
    private Long userId;

    @NotEmpty(message = "Seat class is required")
    private String seatClass;

    @Min(value = 1, message = "At least one passenger is required")
    private int numberOfPassengers;

    private double totalCost;

    @NotEmpty(message = "Status is required")
    private String status; // e.g., BOOKED, CANCELLED

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Passenger> passengerDetails = new ArrayList<>();

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Long getFlightId() {
		return flightId;
	}

	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(String seatClass) {
		this.seatClass = seatClass;
	}

	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}

	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<Passenger> getPassengerDetails() {
		return passengerDetails;
	}

	public void setPassengerDetails(List<Passenger> passengerDetails) {
		this.passengerDetails = passengerDetails;
	}

	public Booking(Long bookingId, @NotNull(message = "Flight ID is required") Long flightId,
			@NotNull(message = "User ID is required") Long userId,
			@NotEmpty(message = "Seat class is required") String seatClass,
			@Min(value = 1, message = "At least one passenger is required") int numberOfPassengers, double totalCost,
			@NotEmpty(message = "Status is required") String status, LocalDateTime createdAt, LocalDateTime updatedAt,
			List<Passenger> passengerDetails) {
		super();
		this.bookingId = bookingId;
		this.flightId = flightId;
		this.userId = userId;
		this.seatClass = seatClass;
		this.numberOfPassengers = numberOfPassengers;
		this.totalCost = totalCost;
		this.status = status;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.passengerDetails = passengerDetails;
	}

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
    

	
}
