package com.Flight_Management.BookingMicroservice.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;

@Entity
public class Passenger {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long passengerId;

    @NotEmpty(message = "Passenger name is required")
    private String name;

    @Min(value = 1, message = "Passenger age must be valid")
    private int age;

    @NotEmpty(message = "Gender is required")
    private String gender;

    @NotEmpty(message = "Passenger status is required")
    private String status; // e.g., Confirmed, Waiting

    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;

	public Long getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(Long passengerId) {
		this.passengerId = passengerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public Passenger(Long passengerId, @NotEmpty(message = "Passenger name is required") String name,
			@Min(value = 1, message = "Passenger age must be valid") int age,
			@NotEmpty(message = "Gender is required") String gender,
			@NotEmpty(message = "Passenger status is required") String status, Booking booking) {
		super();
		this.passengerId = passengerId;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.status = status;
		this.booking = booking;
	}

	public Passenger() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
	
}
