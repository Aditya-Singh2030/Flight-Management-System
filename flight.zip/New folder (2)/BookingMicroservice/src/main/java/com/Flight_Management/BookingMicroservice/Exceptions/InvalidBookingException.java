package com.Flight_Management.BookingMicroservice.Exceptions;

public class InvalidBookingException extends Exception{

	public InvalidBookingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
