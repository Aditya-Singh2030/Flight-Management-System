package com.Flight_Management.BookingMicroservice.Exceptions;

public class InvalidPassengerException extends Exception{

	public InvalidPassengerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
