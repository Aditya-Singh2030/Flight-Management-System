package com.Flight_Management.BookingMicroservice.FeingClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "FLIGHT-SERVICE", url = "http://localhost:8081/api/flights")
public interface FlightClients {
	
	@GetMapping("/price")
    double getPrice(@RequestParam String seatClass, @RequestParam Long flightId);
	
	@PutMapping("/seats/reduce")
    void reduceSeatCount(@RequestParam Long flightId, @RequestParam String seatClass, @RequestParam int count);


}
