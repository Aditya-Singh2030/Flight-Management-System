package com.Flight_Management.BookingMicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Flight_Management.BookingMicroservice.Entity.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long>{

}
