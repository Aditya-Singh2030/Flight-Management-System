package com.Flight_Management.BookingMicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Flight_Management.BookingMicroservice.Entity.Passenger;

@Repository
public interface PassengerRepository extends JpaRepository<Passenger, Long>{

}
