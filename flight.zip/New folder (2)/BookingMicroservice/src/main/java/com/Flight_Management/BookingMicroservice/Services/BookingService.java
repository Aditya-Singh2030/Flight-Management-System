package com.Flight_Management.BookingMicroservice.Services;

import java.util.List;

import com.Flight_Management.BookingMicroservice.Exceptions.InvalidBookingException;
import com.Flight_Management.BookingMicroservice.Exceptions.InvalidPassengerException;
import com.Flight_Management.BookingMicroservice.Utility.BookingDto;

public interface BookingService {
	
	BookingDto addBooking(BookingDto bookingDTO) throws InvalidPassengerException,InvalidBookingException;
    List<BookingDto> getAllBookings();
    BookingDto getBookingById(Long id) throws InvalidBookingException;
    BookingDto updateBooking(Long id, BookingDto bookingDTO) throws InvalidBookingException;
    void deleteBooking(Long id) throws InvalidBookingException;

}
