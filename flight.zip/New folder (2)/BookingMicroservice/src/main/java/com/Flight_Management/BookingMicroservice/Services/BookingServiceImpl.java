package com.Flight_Management.BookingMicroservice.Services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;

import com.Flight_Management.BookingMicroservice.Entity.Booking;
import com.Flight_Management.BookingMicroservice.Entity.Passenger;
import com.Flight_Management.BookingMicroservice.Exceptions.InvalidBookingException;
import com.Flight_Management.BookingMicroservice.Exceptions.InvalidPassengerException;
import com.Flight_Management.BookingMicroservice.FeingClient.FlightClients;
import com.Flight_Management.BookingMicroservice.Repository.BookingRepository;
import com.Flight_Management.BookingMicroservice.Repository.PassengerRepository;
import com.Flight_Management.BookingMicroservice.Utility.BookingDto;

@Service
public class BookingServiceImpl implements BookingService{
	
	@Autowired
	private BookingRepository bookingRepository;
	@Autowired
	private PassengerRepository passengerRepository;
	@Autowired
	private FlightClients client;
	@Autowired
	private ModelMapper mapper;

	@Override
	public BookingDto addBooking(BookingDto bookingDTO) throws InvalidPassengerException, InvalidBookingException {
		if (bookingDTO.getPassengerDetails() == null || bookingDTO.getPassengerDetails().isEmpty()) {
	        throw new InvalidPassengerException("Passenger details are required");
	    }

	    int numPassengers = bookingDTO.getPassengerDetails().size();

	    // Get price per seat from Flight Microservice
	    double seatPrice;
	    try {
	        seatPrice = client.getPrice(bookingDTO.getSeatClass(), bookingDTO.getFlightId());
	    } catch (Exception e) {
	        throw new InvalidBookingException("Failed to get seat price: " + e.getMessage());
	    }

	    double totalCost = seatPrice * numPassengers;

	    // Try to reduce seat count
	    try {
	        client.reduceSeatCount(bookingDTO.getFlightId(), bookingDTO.getSeatClass(), numPassengers);
	    } catch (Exception e) {
	        throw new InvalidBookingException("Failed to reduce seat count: " + e.getMessage());
	    }

	    // Map and save Booking
	    Booking booking = mapper.map(bookingDTO, Booking.class);
	    booking.setTotalCost(totalCost);
	    booking.setStatus("CONFIRMED");
	    booking.setCreatedAt(LocalDateTime.now());
	    booking.setUpdatedAt(LocalDateTime.now());

	    // Map and save Passenger(s)
	    List<Passenger> passengers = bookingDTO.getPassengerDetails().stream().map(pDTO -> {
	        Passenger p = mapper.map(pDTO, Passenger.class);
	        p.setBooking(booking);
	        p.setStatus("BOOKED");
	        return p;
	    }).collect(Collectors.toList());

	    booking.setPassengerDetails(passengers);

	    bookingRepository.save(booking); // saves passengers too due to cascade

	    return mapper.map(booking, BookingDto.class);
	}

	@Override
	public List<BookingDto> getAllBookings() {
		return bookingRepository.findAll()
                .stream()
                .map(booking -> mapper.map(booking, BookingDto.class))
                .collect(Collectors.toList());
	}

	@Override
	public BookingDto getBookingById(Long id) throws InvalidBookingException {
		Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new InvalidBookingException("Booking ID not found: " + id));
        return mapper.map(booking, BookingDto.class);
	}

	@Override
	public BookingDto updateBooking(Long id, BookingDto bookingDTO) throws InvalidBookingException {
		Booking existing = bookingRepository.findById(id)
                .orElseThrow(() -> new InvalidBookingException("Booking ID not found: " + id));

        existing.setStatus(bookingDTO.getStatus());
        existing.setUpdatedAt(LocalDateTime.now());

        Booking updated = bookingRepository.save(existing);
        return mapper.map(updated, BookingDto.class);
	}

	@Override
	public void deleteBooking(Long id) throws InvalidBookingException {
		Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new InvalidBookingException("Booking ID not found: " + id));
        bookingRepository.delete(booking);
		
	}

}
