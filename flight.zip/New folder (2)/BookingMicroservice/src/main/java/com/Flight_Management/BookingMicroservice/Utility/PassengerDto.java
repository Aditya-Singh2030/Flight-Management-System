package com.Flight_Management.BookingMicroservice.Utility;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;

public class PassengerDto {
	
	private Long passengerId;

    @NotEmpty(message = "Name is required")
    private String name;

    @Min(value = 1, message = "Age must be at least 1")
    private int age;

    @NotEmpty(message = "Gender is required")
    private String gender;

    private String status;

	public Long getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(Long passengerId) {
		this.passengerId = passengerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public PassengerDto(Long passengerId, @NotEmpty(message = "Name is required") String name,
			@Min(value = 1, message = "Age must be at least 1") int age,
			@NotEmpty(message = "Gender is required") String gender, String status) {
		super();
		this.passengerId = passengerId;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.status = status;
	}

	public PassengerDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
	
}
