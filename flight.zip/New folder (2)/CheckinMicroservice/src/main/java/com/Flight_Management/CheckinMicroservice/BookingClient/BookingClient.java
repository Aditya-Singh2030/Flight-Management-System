package com.Flight_Management.CheckinMicroservice.BookingClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.Flight_Management.CheckinMicroservice.Utility.BookingDto;

@FeignClient(name = "BOOKING-SERVICE")
public interface BookingClient {
	
	@GetMapping("/api/booking/{bookingId}")
    BookingDto getBookingById(@PathVariable Long bookingId);
	
}
