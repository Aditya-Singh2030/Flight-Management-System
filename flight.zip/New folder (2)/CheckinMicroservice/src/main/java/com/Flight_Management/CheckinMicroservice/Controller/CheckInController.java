package com.Flight_Management.CheckinMicroservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Flight_Management.CheckinMicroservice.Exception.InvalidCheckInExceptions;
import com.Flight_Management.CheckinMicroservice.Service.CheckInService;
import com.Flight_Management.CheckinMicroservice.Utility.CheckinDto;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/checkin")
public class CheckInController {
	
	@Autowired
    private CheckInService checkInService;

    @PostMapping("/add")
    public ResponseEntity<CheckinDto> addCheckIn(@Valid @RequestBody CheckinDto dto) throws InvalidCheckInExceptions {
        return new ResponseEntity<>(checkInService.addCheckIn(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CheckinDto> getById(@PathVariable Long id) throws InvalidCheckInExceptions {
        return new ResponseEntity<>(checkInService.getCheckInById(id), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<List<CheckinDto>> getAll() {
        return new ResponseEntity<>(checkInService.getAllCheckIns(), HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<CheckinDto> update(@PathVariable Long id, @RequestBody CheckinDto dto) throws InvalidCheckInExceptions {
        return new ResponseEntity<>(checkInService.updateCheckIn(id, dto), HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) throws InvalidCheckInExceptions {
        checkInService.deleteCheckIn(id);
        return new ResponseEntity<>("Check-in deleted", HttpStatus.OK);
    }

}
