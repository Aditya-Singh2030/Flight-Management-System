package com.Flight_Management.CheckinMicroservice.Entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;

@Entity
public class CheckIn {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long checkInId;
	private Long bookingId;
	private Long flightId;
	@NotEmpty(message = "Seat number is required")
	private String seatNumber;
	private LocalDate checkInDate;
	private String status;
	public Long getCheckInId() {
		return checkInId;
	}
	public void setCheckInId(Long checkInId) {
		this.checkInId = checkInId;
	}
	public Long getBookingId() {
		return bookingId;
	}
	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public LocalDate getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(LocalDate checkInDate) {
		this.checkInDate = checkInDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getFlightId() {
		return flightId;
	}
	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}
	public CheckIn(Long checkInId, Long bookingId, Long flightId,
			@NotEmpty(message = "Seat number is required") String seatNumber, LocalDate checkInDate, String status) {
		super();
		this.checkInId = checkInId;
		this.bookingId = bookingId;
		this.flightId = flightId;
		this.seatNumber = seatNumber;
		this.checkInDate = checkInDate;
		this.status = status;
	}
	public CheckIn() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
