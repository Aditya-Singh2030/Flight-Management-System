package com.Flight_Management.CheckinMicroservice.Exception;

public class InvalidCheckInExceptions extends Exception{

	public InvalidCheckInExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
