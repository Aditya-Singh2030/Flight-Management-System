package com.Flight_Management.CheckinMicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Flight_Management.CheckinMicroservice.Entity.CheckIn;

@Repository
public interface CheckInRepository extends JpaRepository<CheckIn, Long>{

	boolean existsBySeatNumberAndBookingId(String seatNumber, Long bookingId);

}
