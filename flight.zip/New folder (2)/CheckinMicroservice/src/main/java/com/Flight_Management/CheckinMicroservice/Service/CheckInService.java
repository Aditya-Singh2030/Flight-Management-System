package com.Flight_Management.CheckinMicroservice.Service;

import java.util.List;

import com.Flight_Management.CheckinMicroservice.Exception.InvalidCheckInExceptions;
import com.Flight_Management.CheckinMicroservice.Utility.CheckinDto;

public interface CheckInService {
	
	CheckinDto addCheckIn(CheckinDto checkInDTO) throws InvalidCheckInExceptions;
    CheckinDto getCheckInById(Long id) throws InvalidCheckInExceptions;
    List<CheckinDto> getAllCheckIns();
    CheckinDto updateCheckIn(Long id, CheckinDto checkInDTO) throws InvalidCheckInExceptions;
    void deleteCheckIn(Long id) throws InvalidCheckInExceptions;

}
