package com.Flight_Management.CheckinMicroservice.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Flight_Management.CheckinMicroservice.BookingClient.BookingClient;
import com.Flight_Management.CheckinMicroservice.Entity.CheckIn;
import com.Flight_Management.CheckinMicroservice.Exception.InvalidCheckInExceptions;
import com.Flight_Management.CheckinMicroservice.Repository.CheckInRepository;
import com.Flight_Management.CheckinMicroservice.Utility.BookingDto;
import com.Flight_Management.CheckinMicroservice.Utility.CheckinDto;

@Service
public class CheckInServiceImpl implements CheckInService{
	
	@Autowired
	private CheckInRepository checkInRepository;
	@Autowired
	private ModelMapper mapper;
	@Autowired
	private BookingClient bookingClient;

	@Override
	public CheckinDto addCheckIn(CheckinDto checkInDTO) throws InvalidCheckInExceptions {
		BookingDto booking = null;
	    try {
	        booking = bookingClient.getBookingById(checkInDTO.getBookingId());
	    } catch (Exception e) {
	        throw new InvalidCheckInExceptions("Booking ID not found: " + checkInDTO.getBookingId());
	    }

	    // Enforce uniqueness of seatNumber per flight
	    Long flightId = booking.getFlightId();
	    if (checkInRepository.existsBySeatNumberAndBookingId(checkInDTO.getSeatNumber(), flightId)) {
	        throw new InvalidCheckInExceptions("Seat number already taken for this flight.");
	    }

	    CheckIn checkIn = mapper.map(checkInDTO, CheckIn.class);
	    checkIn.setFlightId(flightId); // store flightId for uniqueness check
	    checkIn.setCheckInDate(LocalDate.now());
	    checkIn.setStatus("CHECKED_IN");

	    CheckIn saved = checkInRepository.save(checkIn);
	    return mapper.map(saved, CheckinDto.class);
	}

	@Override
	public CheckinDto getCheckInById(Long id) throws InvalidCheckInExceptions {
		CheckIn checkIn = checkInRepository.findById(id)
                .orElseThrow(() -> new InvalidCheckInExceptions("Check-in not found with ID: " + id));
        return mapper.map(checkIn, CheckinDto.class);
	}

	@Override
	public List<CheckinDto> getAllCheckIns() {
		return checkInRepository.findAll().stream()
                .map(checkIn -> mapper.map(checkIn, CheckinDto.class))
                .collect(Collectors.toList());
	}

	@Override
	public CheckinDto updateCheckIn(Long id, CheckinDto checkInDTO) throws InvalidCheckInExceptions {
		CheckIn existing = checkInRepository.findById(id)
                .orElseThrow(() -> new InvalidCheckInExceptions("Check-in not found with ID: " + id));

        // Prevent duplicate seat numbers
        if (!existing.getSeatNumber().equals(checkInDTO.getSeatNumber()) &&
            checkInRepository.existsBySeatNumberAndBookingId(checkInDTO.getSeatNumber(), checkInDTO.getBookingId())) {
            throw new InvalidCheckInExceptions("Seat number already assigned for this booking");
        }

        existing.setSeatNumber(checkInDTO.getSeatNumber());
        existing.setCheckInDate(LocalDate.now());
        existing.setStatus(checkInDTO.getStatus());

        CheckIn updated = checkInRepository.save(existing);
        return mapper.map(updated, CheckinDto.class);
	}

	@Override
	public void deleteCheckIn(Long id) throws InvalidCheckInExceptions {
		if (!checkInRepository.existsById(id)) {
            throw new InvalidCheckInExceptions("Check-in not found with ID: " + id);
        }
        checkInRepository.deleteById(id);
		
	}

}
