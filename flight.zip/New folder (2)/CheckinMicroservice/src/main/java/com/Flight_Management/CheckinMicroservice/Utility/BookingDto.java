package com.Flight_Management.CheckinMicroservice.Utility;

import java.time.LocalDateTime;
import java.util.List;


import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class BookingDto {
	
	private Long bookingId;

    private Long flightId;

    private Long userId;

    
    private String seatClass;

    private int numberOfPassengers;

    private double totalCost;

    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private List<PassengerDto> passengerDetails;

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Long getFlightId() {
		return flightId;
	}

	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(String seatClass) {
		this.seatClass = seatClass;
	}

	public int getNumberOfPassengers() {
		return numberOfPassengers;
	}

	public void setNumberOfPassengers(int numberOfPassengers) {
		this.numberOfPassengers = numberOfPassengers;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<PassengerDto> getPassengerDetails() {
		return passengerDetails;
	}

	public void setPassengerDetails(List<PassengerDto> passengerDetails) {
		this.passengerDetails = passengerDetails;
	}

	public BookingDto(Long bookingId, @NotNull(message = "Flight ID is required") Long flightId,
			@NotNull(message = "User ID is required") Long userId,
			@NotEmpty(message = "Seat class is required") String seatClass,
			@Min(value = 1, message = "Passenger count must be at least 1") int numberOfPassengers, double totalCost,
			String status, LocalDateTime createdAt, LocalDateTime updatedAt, List<PassengerDto> passengerDetails) {
		super();
		this.bookingId = bookingId;
		this.flightId = flightId;
		this.userId = userId;
		this.seatClass = seatClass;
		this.numberOfPassengers = numberOfPassengers;
		this.totalCost = totalCost;
		this.status = status;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.passengerDetails = passengerDetails;
	}

	public BookingDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
