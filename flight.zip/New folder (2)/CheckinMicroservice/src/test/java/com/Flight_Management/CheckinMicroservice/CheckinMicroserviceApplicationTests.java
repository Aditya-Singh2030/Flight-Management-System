package com.Flight_Management.CheckinMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckinMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
