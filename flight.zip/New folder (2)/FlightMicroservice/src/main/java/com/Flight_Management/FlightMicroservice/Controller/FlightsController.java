package com.Flight_Management.FlightMicroservice.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Flight_Management.FlightMicroservice.Exception.InvalidFlightException;
import com.Flight_Management.FlightMicroservice.Exception.InvalidSeatException;
import com.Flight_Management.FlightMicroservice.Service.FlightService;
import com.Flight_Management.FlightMicroservice.Utility.FlightDto;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/flights")
public class FlightsController {
	
	@Autowired
	private FlightService flightService;
	
	@PostMapping("/add")
    public ResponseEntity<FlightDto> addFlight(@Valid @RequestBody FlightDto flightDTO) throws InvalidFlightException, InvalidSeatException {
        return new ResponseEntity<>(flightService.addFlight(flightDTO), HttpStatus.CREATED);
    }

    @GetMapping("/")
    public ResponseEntity<List<FlightDto>> getAllFlights() {
        return ResponseEntity.ok(flightService.getAllFlights());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FlightDto> getFlightById(@PathVariable Long id) throws InvalidFlightException {
        return ResponseEntity.ok(flightService.getFlightById(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<FlightDto>> searchFlights(@RequestParam String source,
                                                         @RequestParam String destination,
                                                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(flightService.searchFlights(source, destination, date));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FlightDto> updateFlight(@PathVariable Long id,
                                                  @Valid @RequestBody FlightDto flightDTO) throws InvalidFlightException, InvalidSeatException {
        return ResponseEntity.ok(flightService.updateFlight(id, flightDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFlight(@PathVariable Long id) throws InvalidFlightException {
        flightService.deleteFlight(id);
        return ResponseEntity.ok("Flight with ID " + id + " has been deleted.");
    }
    
    @GetMapping("/price")
    public ResponseEntity<Double> getPrice(@RequestParam String seatClass,
                                           @RequestParam Long flightId) throws InvalidFlightException, InvalidSeatException {
        return ResponseEntity.ok(flightService.getPrice(seatClass, flightId));
    }

    @PutMapping("/seats/reduce")
    public ResponseEntity<String> reduceSeatCount(@RequestParam Long flightId,
                                                  @RequestParam String seatClass,
                                                  @RequestParam int count) throws InvalidFlightException, InvalidSeatException {
        flightService.reduceSeatCount(flightId, seatClass, count);
        return ResponseEntity.ok("Seat count reduced successfully.");
    }

}
