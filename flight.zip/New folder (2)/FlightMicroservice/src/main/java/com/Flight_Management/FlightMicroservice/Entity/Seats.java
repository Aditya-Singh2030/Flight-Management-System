package com.Flight_Management.FlightMicroservice.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Seats {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long seatId;

    private String seatClass; // Economy, Business, First
    private int noOfSeats;
    private double price;
    private int availableSeats;

    @ManyToOne
    private Flights flight;

	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public String getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(String seatClass) {
		this.seatClass = seatClass;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public Flights getFlight() {
		return flight;
	}

	public void setFlight(Flights flight) {
		this.flight = flight;
	}
	
	
	
	public Seats(Long seatId, String seatClass, int noOfSeats, double price, int availableSeats,
			Flights flight) {
		super();
		this.seatId = seatId;
		this.seatClass = seatClass;
		this.noOfSeats = noOfSeats;
		this.price = price;
		this.availableSeats = availableSeats;
		this.flight = flight;
	}

	public Seats() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
