package com.Flight_Management.FlightMicroservice.Exception;

public class InvalidFlightException extends Exception{

	public InvalidFlightException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
