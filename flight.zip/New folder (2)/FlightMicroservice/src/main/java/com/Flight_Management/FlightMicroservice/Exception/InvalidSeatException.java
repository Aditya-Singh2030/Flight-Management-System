package com.Flight_Management.FlightMicroservice.Exception;

public class InvalidSeatException extends Exception{

	public InvalidSeatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
