package com.Flight_Management.FlightMicroservice;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.Flight_Management")
@EntityScan(basePackages = "com.Flight_Management.FlightMicroservice.Entity")
@EnableJpaRepositories(basePackages = "com.Flight_Management.FlightMicroservice.Repository")
public class FlightMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightMicroserviceApplication.class, args);
	}
	
	@Bean
	public ModelMapper mapper() {
		return new ModelMapper();
	}

}
