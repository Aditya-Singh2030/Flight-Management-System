package com.Flight_Management.FlightMicroservice.Repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Flight_Management.FlightMicroservice.Entity.Flights;

@Repository
public interface FlightRepository extends JpaRepository<Flights, Long>{

	List<Flights> findBySourceAndDestinationAndDepartureDate(String source, String destination, LocalDate date);

}
