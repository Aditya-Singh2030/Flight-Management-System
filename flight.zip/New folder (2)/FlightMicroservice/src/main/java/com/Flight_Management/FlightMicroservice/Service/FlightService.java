package com.Flight_Management.FlightMicroservice.Service;

import java.time.LocalDate;
import java.util.List;

import com.Flight_Management.FlightMicroservice.Exception.InvalidFlightException;
import com.Flight_Management.FlightMicroservice.Exception.InvalidSeatException;
import com.Flight_Management.FlightMicroservice.Utility.FlightDto;

public interface FlightService {
	
	FlightDto addFlight(FlightDto flightDTO) throws InvalidFlightException, InvalidSeatException;

    List<FlightDto> getAllFlights();

    FlightDto getFlightById(Long id) throws InvalidFlightException;

    List<FlightDto> searchFlights(String source, String destination, LocalDate date);

    FlightDto updateFlight(Long id, FlightDto flightDTO) throws InvalidFlightException, InvalidSeatException;

    void deleteFlight(Long id) throws InvalidFlightException;

	double getPrice(String seatClass, Long flightId) throws InvalidFlightException,InvalidSeatException;

	void reduceSeatCount(Long flightId, String seatClass, int count)throws InvalidFlightException,InvalidSeatException;

}
