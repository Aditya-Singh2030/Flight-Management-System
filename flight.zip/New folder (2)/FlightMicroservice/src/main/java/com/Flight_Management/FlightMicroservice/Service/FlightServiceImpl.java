package com.Flight_Management.FlightMicroservice.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Flight_Management.FlightMicroservice.Entity.Flights;
import com.Flight_Management.FlightMicroservice.Entity.Seats;
import com.Flight_Management.FlightMicroservice.Exception.InvalidFlightException;
import com.Flight_Management.FlightMicroservice.Exception.InvalidSeatException;
import com.Flight_Management.FlightMicroservice.Repository.FlightRepository;
import com.Flight_Management.FlightMicroservice.Repository.SeatRepository;
import com.Flight_Management.FlightMicroservice.Utility.FlightDto;
import com.Flight_Management.FlightMicroservice.Utility.SeatDTO;

@Service
public class FlightServiceImpl implements FlightService{
	
	@Autowired
	private FlightRepository flightRepository;
	@Autowired
    private SeatRepository seatRepository;
	@Autowired
	private ModelMapper mapper;

	@Override
	public FlightDto addFlight(FlightDto flightDTO) throws InvalidFlightException, InvalidSeatException {
		this.validateFlightData(flightDTO);

        Flights flight = mapper.map(flightDTO, Flights.class);
        flight = flightRepository.save(flight);

        List<Seats> seatEntities = new ArrayList<>();
        for (SeatDTO seatDTO : flightDTO.getSeats()) {
            validateSeatData(seatDTO);
            Seats seat = mapper.map(seatDTO, Seats.class);
            seat.setFlight(flight);
            seatEntities.add(seat);
        }
        seatRepository.saveAll(seatEntities);
        flight.setSeats(seatEntities);

        return mapper.map(flight, FlightDto.class);
	}

	@Override
	public List<FlightDto> getAllFlights() {
		return flightRepository.findAll().stream()
                .map(flight -> mapper.map(flight, FlightDto.class))
                .collect(Collectors.toList());
	}

	@Override
	public FlightDto getFlightById(Long id) throws InvalidFlightException {
		Flights flight = flightRepository.findById(id)
                .orElseThrow(() -> new InvalidFlightException("Flight not found with ID: " + id));
        return mapper.map(flight, FlightDto.class);
	}

	@Override
	public List<FlightDto> searchFlights(String source, String destination, LocalDate date) {
		List<Flights> flights = flightRepository.findBySourceAndDestinationAndDepartureDate(source, destination, date);
        return flights.stream()
                .map(flight -> mapper.map(flight, FlightDto.class))
                .collect(Collectors.toList());
	}

	@Override
	public FlightDto updateFlight(Long id, FlightDto flightDTO) throws InvalidFlightException, InvalidSeatException {
		validateFlightData(flightDTO);

        Flights existingFlight = flightRepository.findById(id)
                .orElseThrow(() -> new InvalidFlightException("Flight not found with ID: " + id));

        // Update basic flight details
        existingFlight.setAirline(flightDTO.getAirline());
        existingFlight.setSource(flightDTO.getSource());
        existingFlight.setDestination(flightDTO.getDestination());
        existingFlight.setDepartureDate(flightDTO.getDepartureDate());
        existingFlight.setDepartureTime(flightDTO.getDepartureTime());
        existingFlight.setArrivalDate(flightDTO.getArrivalDate());
        existingFlight.setArrivalTime(flightDTO.getArrivalTime());
        existingFlight.setTotalSeats(flightDTO.getTotalSeats());

        existingFlight = flightRepository.save(existingFlight);

        // Delete existing seats if necessary (if not using cascade)
        seatRepository.deleteAllByFlight(existingFlight);

        // Save new seat configuration
        List<Seats> newSeats = new ArrayList<>();
        for (SeatDTO seatDTO : flightDTO.getSeats()) {
            validateSeatData(seatDTO);
            Seats seat = mapper.map(seatDTO, Seats.class);
            seat.setFlight(existingFlight);
            newSeats.add(seat);
        }
        seatRepository.saveAll(newSeats);
        existingFlight.setSeats(newSeats);

        return mapper.map(existingFlight, FlightDto.class);
	}

	@Override
	public void deleteFlight(Long id) throws InvalidFlightException {
		// TODO Auto-generated method stub
		Flights flight = flightRepository.findById(id)
                .orElseThrow(() -> new InvalidFlightException("Flight not found with ID: " + id));
        
        seatRepository.deleteAllByFlight(flight); // optional if not cascade
        flightRepository.delete(flight);
	}
	
	private void validateFlightData(FlightDto flightDTO) throws InvalidFlightException {
        if (flightDTO.getArrivalDate().isBefore(flightDTO.getDepartureDate())) {
            throw new InvalidFlightException("Arrival date cannot be before departure date");
        }
    }
	
	private void validateSeatData(SeatDTO seatDTO) throws InvalidSeatException {
        if (seatDTO.getNoOfSeats() <= 0 || seatDTO.getPrice() <= 0) {
            throw new InvalidSeatException("Seat count and price must be greater than 0");
        }
    }
	
	@Override
    public double getPrice(String seatClass, Long flightId) throws InvalidFlightException, InvalidSeatException {
		Flights flight = flightRepository.findById(flightId)
	            .orElseThrow(() -> new InvalidFlightException("Flight not found"));

	    return flight.getSeats().stream()
	            .filter(s -> s.getSeatClass().equalsIgnoreCase(seatClass))
	            .findFirst()
	            .orElseThrow(() -> new InvalidSeatException("Seat class not found"))
	            .getPrice();
    }
	
	@Override
    public void reduceSeatCount(Long flightId, String seatClass, int count) throws InvalidFlightException, InvalidSeatException {
		Flights flight = flightRepository.findById(flightId)
	            .orElseThrow(() -> new InvalidFlightException("Flight not found"));

	    Seats seat = flight.getSeats().stream()
	            .filter(s -> s.getSeatClass().equalsIgnoreCase(seatClass))
	            .findFirst()
	            .orElseThrow(() -> new InvalidSeatException("Seat class not found"));

	    if (seat.getAvailableSeats() < count) {
	        throw new InvalidSeatException("Not enough available seats in class: " + seatClass);
	    }

	    seat.setAvailableSeats(seat.getAvailableSeats() - count);
	    flight.setTotalSeats(flight.getTotalSeats() - count);

	    seatRepository.save(seat);
	    flightRepository.save(flight);
    }

}
