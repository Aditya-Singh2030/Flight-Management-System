package com.Flight_Management.FlightMicroservice.Utility;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

public class FlightDto {
	
	private Long id;

    @NotEmpty(message = "Airline name is required")
    private String airline;

    @NotEmpty(message = "Source is required")
    private String source;

    @NotEmpty(message = "Destination is required")
    private String destination;

    @NotNull(message = "Departure date is required")
    @PastOrPresent(message = "Departure date should be current or past date")
    private LocalDate departureDate;

    @NotNull(message = "Departure time is required")
    private LocalTime departureTime;

    @NotNull(message = "Arrival date is required")
    @FutureOrPresent(message = "Arrival date should be today or in the future")
    private LocalDate arrivalDate;

    @NotNull(message = "Arrival time is required")
    private LocalTime arrivalTime;

    @Min(value = 1, message = "Total seats must be at least 1")
    private int totalSeats;

    private List<SeatDTO> seats;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public LocalDate getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(LocalDate departureDate) {
		this.departureDate = departureDate;
	}

	public LocalTime getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(LocalTime departureTime) {
		this.departureTime = departureTime;
	}

	public LocalDate getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(LocalDate arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public LocalTime getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(LocalTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public int getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	public List<SeatDTO> getSeats() {
		return seats;
	}

	public void setSeats(List<SeatDTO> seats) {
		this.seats = seats;
	}

	public FlightDto(Long id, @NotEmpty(message = "Airline name is required") String airline,
			@NotEmpty(message = "Source is required") String source,
			@NotEmpty(message = "Destination is required") String destination,
			@NotNull(message = "Departure date is required") @PastOrPresent(message = "Departure date should be current or past date") LocalDate departureDate,
			@NotNull(message = "Departure time is required") LocalTime departureTime,
			@NotNull(message = "Arrival date is required") @FutureOrPresent(message = "Arrival date should be today or in the future") LocalDate arrivalDate,
			@NotNull(message = "Arrival time is required") LocalTime arrivalTime,
			@Min(value = 1, message = "Total seats must be at least 1") int totalSeats, List<SeatDTO> seats) {
		super();
		this.id = id;
		this.airline = airline;
		this.source = source;
		this.destination = destination;
		this.departureDate = departureDate;
		this.departureTime = departureTime;
		this.arrivalDate = arrivalDate;
		this.arrivalTime = arrivalTime;
		this.totalSeats = totalSeats;
		this.seats = seats;
	}

	public FlightDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
	
}
