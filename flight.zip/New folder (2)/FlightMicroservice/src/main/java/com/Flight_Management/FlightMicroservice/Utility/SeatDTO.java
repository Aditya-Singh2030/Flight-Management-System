package com.Flight_Management.FlightMicroservice.Utility;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;

public class SeatDTO {
	
	private Long seatId;

    @NotEmpty(message = "Seat class is required")
    private String seatClass;

    @Min(value = 1, message = "Number of seats must be at least 1")
    private int noOfSeats;

    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
    private double price;

    @Min(value = 0, message = "Available seats cannot be negative")
    private int availableSeats;

	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public String getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(String seatClass) {
		this.seatClass = seatClass;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public SeatDTO(Long seatId, @NotEmpty(message = "Seat class is required") String seatClass,
			@Min(value = 1, message = "Number of seats must be at least 1") int noOfSeats,
			@DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0") double price,
			@Min(value = 0, message = "Available seats cannot be negative") int availableSeats) {
		super();
		this.seatId = seatId;
		this.seatClass = seatClass;
		this.noOfSeats = noOfSeats;
		this.price = price;
		this.availableSeats = availableSeats;
	}

	public SeatDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
	
}
