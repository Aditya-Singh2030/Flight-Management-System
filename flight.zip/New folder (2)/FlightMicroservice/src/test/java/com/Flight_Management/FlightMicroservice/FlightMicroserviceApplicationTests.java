package com.Flight_Management.FlightMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
