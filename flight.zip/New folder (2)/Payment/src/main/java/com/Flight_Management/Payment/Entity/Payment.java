package com.Flight_Management.Payment.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Payment {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long bookingId;
    private String receiptEmail;
    private String currency;
    private Long amount;
    private String stripePaymentId;
    private String status;

    private LocalDateTime createdAt;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public String getReceiptEmail() {
		return receiptEmail;
	}

	public void setReceiptEmail(String receiptEmail) {
		this.receiptEmail = receiptEmail;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public String getStripePaymentId() {
		return stripePaymentId;
	}

	public void setStripePaymentId(String stripePaymentId) {
		this.stripePaymentId = stripePaymentId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public Payment(Long id, Long bookingId, String receiptEmail, String currency, Long amount, String stripePaymentId,
			String status, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.bookingId = bookingId;
		this.receiptEmail = receiptEmail;
		this.currency = currency;
		this.amount = amount;
		this.stripePaymentId = stripePaymentId;
		this.status = status;
		this.createdAt = createdAt;
	}

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
