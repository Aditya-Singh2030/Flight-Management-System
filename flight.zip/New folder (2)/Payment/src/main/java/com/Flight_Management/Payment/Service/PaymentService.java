package com.Flight_Management.Payment.Service;

import java.util.List;

import com.Flight_Management.Payment.Utility.PaymentDto;

public interface PaymentService {
	
	PaymentDto processPayment(PaymentDto paymentDTO);
    List<PaymentDto> getAllPayments();
    PaymentDto getPaymentById(Long id);

}
