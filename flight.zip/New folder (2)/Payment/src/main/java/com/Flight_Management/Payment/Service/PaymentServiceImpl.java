package com.Flight_Management.Payment.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Flight_Management.Payment.Entity.Payment;
import com.Flight_Management.Payment.Repository.PaymentRepository;
import com.Flight_Management.Payment.Utility.PaymentDto;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;

@Service
public class PaymentServiceImpl implements PaymentService{
	@Autowired
	private PaymentRepository paymentRepository;
	@Autowired
	private ModelMapper mapper;

	@Override
	public PaymentDto processPayment(PaymentDto paymentDTO) {
		try {
            Map<String, Object> params = new HashMap<>();
            params.put("amount", paymentDTO.getAmount());
            params.put("currency", paymentDTO.getCurrency());
            params.put("payment_method_types", List.of(paymentDTO.getPaymentMethodType()));
            params.put("receipt_email", paymentDTO.getReceiptEmail());

            PaymentIntent intent = PaymentIntent.create(params);

            Payment payment = new Payment();
            payment.setBookingId(paymentDTO.getBookingId());
            payment.setAmount(paymentDTO.getAmount());
            payment.setCurrency(paymentDTO.getCurrency());
            payment.setReceiptEmail(paymentDTO.getReceiptEmail());
            payment.setStripePaymentId(intent.getId());
            payment.setStatus(intent.getStatus());
            payment.setCreatedAt(LocalDateTime.now());

            paymentRepository.save(payment);
            return mapper.map(payment, PaymentDto.class);

        } catch (StripeException e) {
            throw new RuntimeException("Stripe payment failed: " + e.getMessage());
        }
	}

	@Override
	public List<PaymentDto> getAllPayments() {
		return paymentRepository.findAll().stream()
                .map(p -> mapper.map(p, PaymentDto.class))
                .collect(Collectors.toList());
	}

	@Override
	public PaymentDto getPaymentById(Long id) {
		return paymentRepository.findById(id)
                .map(p -> mapper.map(p, PaymentDto.class))
                .orElseThrow(() -> new RuntimeException("Payment not found"));
	}

}
