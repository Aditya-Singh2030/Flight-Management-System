package com.Flight_Management.Payment.Utility;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class PaymentDto {
	
	@NotNull(message = "Amount is required")
    private Long amount; // In cents

    @NotEmpty(message = "Currency is required")
    private String currency;

    @NotEmpty(message = "Payment method type is required")
    private String paymentMethodType; // e.g., "card"

    @NotEmpty(message = "Receipt email is required")
    @Email(message = "Invalid email")
    private String receiptEmail;

    @NotNull(message = "Booking ID is required")
    private Long bookingId;

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPaymentMethodType() {
		return paymentMethodType;
	}

	public void setPaymentMethodType(String paymentMethodType) {
		this.paymentMethodType = paymentMethodType;
	}

	public String getReceiptEmail() {
		return receiptEmail;
	}

	public void setReceiptEmail(String receiptEmail) {
		this.receiptEmail = receiptEmail;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public PaymentDto(@NotNull(message = "Amount is required") Long amount,
			@NotEmpty(message = "Currency is required") String currency,
			@NotEmpty(message = "Payment method type is required") String paymentMethodType,
			@NotEmpty(message = "Receipt email is required") @Email(message = "Invalid email") String receiptEmail,
			@NotNull(message = "Booking ID is required") Long bookingId) {
		super();
		this.amount = amount;
		this.currency = currency;
		this.paymentMethodType = paymentMethodType;
		this.receiptEmail = receiptEmail;
		this.bookingId = bookingId;
	}

	public PaymentDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
