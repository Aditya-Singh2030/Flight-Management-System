package com.Flight_Management.UserMicroservice.Exception;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class GlobalException extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionResponce> handelsAllExceptions(Exception ex , WebRequest request){
		
		ExceptionResponce exceptionResponce = new ExceptionResponce(LocalDate.now(),ex.getMessage(),request.getDescription(false),HttpStatus.INTERNAL_SERVER_ERROR.toString());
		
		return new ResponseEntity<ExceptionResponce>(exceptionResponce,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	
	@ExceptionHandler({UserNotFoundException.class})
	public ResponseEntity<ExceptionResponce> handelsCustomExceptions(Exception ex , WebRequest request){
		
		ExceptionResponce exceptionResponce = new ExceptionResponce(LocalDate.now(),ex.getMessage(),request.getDescription(false),HttpStatus.INTERNAL_SERVER_ERROR.toString());
		
		return new ResponseEntity<ExceptionResponce>(exceptionResponce,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {	
			    
		List<String> errors = ex.getBindingResult()
		        .getFieldErrors()
		        .stream()
		        .map(error -> error.getField() + ": " + error.getDefaultMessage())
		        .collect(Collectors.toList());
		
		Map<String, Object> responseBody = new LinkedHashMap<>();
	    responseBody.put("timestamp", LocalDateTime.now());
	    responseBody.put("status", status.value());
	    responseBody.put("errors", errors);
			    
	    return new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST);
		}

}
