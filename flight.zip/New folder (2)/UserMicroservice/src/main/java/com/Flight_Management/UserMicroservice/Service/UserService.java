package com.Flight_Management.UserMicroservice.Service;

import java.util.List;

import com.Flight_Management.UserMicroservice.Exception.UserNotFoundException;
import com.Flight_Management.UserMicroserviceUtility.UserDto;

public interface UserService {
	
	UserDto addUser(UserDto userDTO);
	UserDto getUser(Long userId) throws UserNotFoundException;
    List<UserDto> getAllUsers();
    UserDto updateUser(Long userId, UserDto userDTO) throws UserNotFoundException;
    void deleteUser(Long userId) throws UserNotFoundException;

}
