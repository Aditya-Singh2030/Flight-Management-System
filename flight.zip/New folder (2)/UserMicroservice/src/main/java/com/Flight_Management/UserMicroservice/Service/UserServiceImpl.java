package com.Flight_Management.UserMicroservice.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Flight_Management.UserMicroservice.Entity.User;
import com.Flight_Management.UserMicroservice.Exception.UserNotFoundException;
import com.Flight_Management.UserMicroservice.Repository.UserRepository;
import com.Flight_Management.UserMicroserviceUtility.UserDto;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private ModelMapper mapper;

	@Override
	public UserDto addUser(UserDto userDTO) {
		User user = mapper.map(userDTO, User.class);
        return mapper.map(userRepository.save(user), UserDto.class);
	}

	@Override
	public UserDto getUser(Long userId) throws UserNotFoundException {
		User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User ID not found: " + userId));
        return mapper.map(user, UserDto.class);
	}

	@Override
	public List<UserDto> getAllUsers() {
		return userRepository.findAll().stream()
                .map(user -> mapper.map(user, UserDto.class))
                .collect(Collectors.toList());
	}

	@Override
	public UserDto updateUser(Long userId, UserDto userDTO) throws UserNotFoundException {
		User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User ID not found: " + userId));

        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setPhone(userDTO.getPhone());

        return mapper.map(userRepository.save(user), UserDto.class);
	}

	@Override
	public void deleteUser(Long userId) throws UserNotFoundException {
		userRepository.deleteById(userId);
		
	}

}
