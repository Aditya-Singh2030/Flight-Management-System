package com.Flight_Management.UserMicroserviceUtility;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

public class UserDto {
	
	private Long userId;

    @NotEmpty(message = "Name is required")
    private String name;

    @Email(message = "Invalid email")
    private String email;

    @NotEmpty(message = "Phone number is required")
    private String phone;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public UserDto(Long userId, @NotEmpty(message = "Name is required") String name,
			@Email(message = "Invalid email") String email,
			@NotEmpty(message = "Phone number is required") String phone) {
		super();
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.phone = phone;
	}

	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

	
}
